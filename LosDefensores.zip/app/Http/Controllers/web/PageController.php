<?php

namespace App\Http\Controllers\web;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

use App\Post;
use App\Category;
use App\Tag;
use App\Advert;
use App\Economy;

use Carbon\Carbon;

class PageController extends Controller
{
    function index(){
        //economies moneda
        $dollarV = Economy::orderby('id', 'DESC')->where('name', 'Dolar Venta')->first();
        $dollarC = Economy::orderby('id', 'DESC')->where('name', 'Dolar Compra')->first();
        $euroV = Economy::orderby('id', 'DESC')->where('name', 'Euro Venta')->first();
        $euroC = Economy::orderby('id', 'DESC')->where('name', 'Euro Compra')->first();
        $dollarV = Economy::orderby('id', 'DESC')->where('name', 'Dolar Venta')->first();
        $dollarV = Economy::orderby('id', 'DESC')->where('name', 'Dolar Venta')->first();
        $dollarV = Economy::orderby('id', 'DESC')->where('name', 'Dolar Venta')->first();

        //economies fuel
        $gp = Economy::orderby('id', 'DESC')->where('name', 'Gasolina Premiun')->first();
        $gr = Economy::orderby('id', 'DESC')->where('name', 'Gasolina Regular')->first();
        $dp = Economy::orderby('id', 'DESC')->where('name', 'Diesel Premiun')->first();
        $dr = Economy::orderby('id', 'DESC')->where('name', 'Diesel Regular')->first();
        $gasp = Economy::orderby('id', 'DESC')->where('name', 'Gas Propano')->first();
        $gasn = Economy::orderby('id', 'DESC')->where('name', ' Gas Natural')->first();    
       

        $postCat1 = Post::orderby('id', 'DESC')->where('status', 'PUBLISHED')->where('category_id', '1')->first();
        $postCat2 = Post::orderby('id', 'DESC')->where('status', 'PUBLISHED')->where('category_id', '2')->first();
        $postCat3 = Post::orderby('id', 'DESC')->where('status', 'PUBLISHED')->where('category_id', '3')->first();
        $postCat4 = Post::orderby('id', 'DESC')->where('status', 'PUBLISHED')->where('category_id', '4')->first();
        $postCat5 = Post::orderby('id', 'DESC')->where('status', 'PUBLISHED')->where('category_id', '5')->first();
        $postOthers = Post::orderby('id', 'DESC')->where('status', 'PUBLISHED')->where('category_id', '5')->paginate(8);
        $postOpinion = Post::orderby('id', 'DESC')->where('status', 'PUBLISHED')->where('category_id', '6')->paginate(3);
        $advert = Advert::orderby('id', 'DESC')->where('url','!=', 'N/A')->first();
        $fun = Advert::orderby('id', 'DESC')->where('url', 'N/A')->first();
        $last3 = Post::orderby('id', 'DESC')->where('status', 'PUBLISHED')->paginate(3);
        return view('web.home', compact([
            'postCat1',
            'postCat2',
            'postCat3',
            'postCat4',
            'postCat5',
            'postOthers',
            'postOpinion',
            'advert',
            'dollarV',
            'dollarC',
            'euroV',
            'euroC',
            'gp',
            'gr',
            'dp',
            'dr',
            'gasp',
            'gasn',
            'fun',
            'last3'
        ]));
    }

    function search(Request $request){
        $name = $request->get('name');
        
        $postsearch = Post::orderby('id', 'DESC')
                    ->name($name)
                    ->where('status', 'PUBLISHED')
                    ->paginate(6);
        if ($postsearch->isEmpty()) {
            $cont = true;
        }else{
            $cont = false;
        }
        return view('web.search', compact([
            'postsearch',
            'name',
            'cont'
        ]));
    }

    function blog(){
        $posts = Post::orderby('id', 'DESC')->where('status', 'PUBLISHED')->paginate(3);
        return view('web.posts', compact('posts'));
    }

    function post($slug){
        $post = Post::where('slug', $slug)->first();
        $category = Post::where('slug', $slug)->pluck('category_id')->first();
        $postsByCat = Post::where('category_id', $category)->orderby('id', 'DESC')->where('status', 'PUBLISHED')->paginate(7);
        return view('web.post', compact([
            'post',
            'postsByCat'
        ]));
    }

    function category($slug){
        $category = Category::where('slug', $slug)->pluck('id')->first();
        $categoryName = Category::where('slug', $slug)->pluck('name')->first();
        $posts = Post::where('category_id', $category)->orderby('id', 'DESC')->where('status', 'PUBLISHED')->paginate(4);
        if ($posts->isEmpty()) {
            $cont = true;
        }else{
            $cont = false;
        }
        return view('web.category', compact([
            'posts',
            'categoryName',
            'cont'
        ]));
    }

    function tag($slug){
        $tagName = Tag::where('slug', $slug)->pluck('name')->first();
        $posts = Post::whereHas('tags', function($query) use ($slug){
            $query->where('slug', $slug);
        })      ->orderby('id', 'DESC')
                ->where('status', 'PUBLISHED')
                ->paginate(4);
        return view('web.tags', compact([
            'posts',
            'tagName'
            ]));
    }


}
