DivTutiempo_FitArBYBYD1ccFGUjAqzjDDjzWl1LUWFrdEY1Zi5KED = document.getElementById('TT_FitArBYBYD1ccFGUjAqzjDDjzWl1LUWFrdEY1Zi5KED');
if(DivTutiempo_FitArBYBYD1ccFGUjAqzjDDjzWl1LUWFrdEY1Zi5KED)
{
DivTutiempo_FitArBYBYD1ccFGUjAqzjDDjzWl1LUWFrdEY1Zi5KED.style.cssText = 'width:215px; height:89px; color:#000000; overflow:hidden;';
DivTutiempo_FitArBYBYD1ccFGUjAqzjDDjzWl1LUWFrdEY1Zi5KED.innerHTML = '<iframe id="TTF_FitArBYBYD1ccFGUjAqzjDDjzWl1LUWFrdEY1Zi5KED" src="https://www.tutiempo.net/s-widget/tt_NXx8MzgyNjI2fG58bnxufDEwODIxOXwzMHwxMXwxfDF8MXwzfDI1fHN8c3xufEU4NkY2Rnw3MUI5RjB8fHwwMDAwMDB8NjZ8M3w2Mnw2MHwxNDR8MjJ8NzR8MHwyMTV8ODl8MjR8Mzd8MTV8MTV8Mjl8NTR8Mjh8RFl8MXw%2C" frameborder="0" scrolling="no" width="100%" height="100%" allowtransparency="allowtransparency" style="overflow:hidden;pointer-events:auto;"></iframe>';
var scriptFitArBYBYD1ccFGUjAqzjDDjzWl1LUWFrdEY1Zi5KED = document.createElement("script");
scriptFitArBYBYD1ccFGUjAqzjDDjzWl1LUWFrdEY1Zi5KED.src = 'https://www.tutiempo.net/s-widget/lcx_FitArBYBYD1ccFGUjAqzjDDjzWl1LUWFrdEY1Zi5KED_eu_'+encodeURIComponent(window.location.hostname);
document.head.appendChild(scriptFitArBYBYD1ccFGUjAqzjDDjzWl1LUWFrdEY1Zi5KED);
}
else {alert("Error en la carga del API del tiempo\nEl cÃ³digo introducido no es correcto\nPara mas informaciÃ³n: www.tutiempo.net");}