@extends('layouts.desing')

@section('advert')
<center>
    <a href=" {{$advert->url}} " target="_blank">
        <img src=" {{$advert->file}} " alt="alternative text" title="{{$advert->name}}" class="img-fluid" alt="">
    </a>
</center>
@endsection



@section('content')

<div class="row main-new">
    <div class="col-md-6 descripcion">
       <a href="categoria/{{$postCat1->category->slug}}"><span class="lastMin">{{$postCat1->category->name}}</span></a> 
            <br>
            <br>
       <span class="MainNewTitle">{{$postCat1->name}}</span>
            <br>
            <br>

       <span class="MainExtract" >
           <p>
            {{$postCat1->excerpt}} </p>
            <b>Etiquetas:</b>
            @foreach ($postCat1->tags as $tag)
    
            <a href="{{route('tag', $tag->slug)}}"> {{$tag->name}}</a>
            @endforeach
       </span>
       
       <p class="text-right"><a href="noticia/{{$postCat1->slug}}">Continuar Leyendo</a></p>
    </div>
    <div class="col-md-6 imagen">
        <a href="/noticia/{{$postCat1->slug}}">
        <img src="{{$postCat1->file}}" class="img-fluid" alt="">
        </a>
        <p class="text-muted small">{{$postCat1->foot}}</p>
    </div>
</div>

    <hr>
<div class="row news">
    <div class="col-md-9 news">
        <div class="row">
            <div class="col-md-6 category">
                <a href="categoria/{{$postCat2->category->slug}}"><span class="categoryTitle">{{$postCat2->category->name}}</span></a>
                <a href="/noticia/{{$postCat2->slug}}">
                    <div class="card-image" style="width:100%; height:250px; background-size: cover;  background-image:url('{{$postCat2->file}}');">
                    </div>
                {{-- <img src="{{$postCat2->file}}" class="img-fluid" alt=""> --}}
                </a>  
                <br> 
                <br> 
                <span class="categoryArticle">{{$postCat2->name}}</span> 
                <br>
                @foreach ($postCat2->tags as $tag)
                <a href="{{route('tag', $tag->slug)}}"> {{$tag->name}}</a>
                @endforeach
            </div>

            <div class="col-md-6 category separador">
                <a href="categoria/{{$postCat3->category->slug}}"><span class="categoryTitle">{{$postCat3->category->name}}</span></a>    
                <a href="/noticia/{{$postCat3->slug}}">
                    <div class="card-image" style="width:100%; height:250px; background-size: cover;  background-image:url('{{$postCat3->file}}');">
                    </div>
                {{-- <img src="{{$postCat3->file}}" class="img-fluid w-100 img-thumbnail" alt="">   --}}
                </a>
                <br> 
                <br> 
                <span class="categoryArticle">{{$postCat3->name}}</span> 
                <br>
                    @foreach ($postCat3->tags as $tag)
                    <a href="{{route('tag', $tag->slug)}}"> {{$tag->name}}</a>
                    @endforeach
            </div>
        </div>
        <br>
        <div class="row">

            <div class="col-md-6">       
                <div class="row">
                    <div class="col-md-12 category ">
                        <hr>
                        <a href="categoria/{{$postCat4->category->slug}}"><span class="categoryTitle">{{$postCat4->category->name}}</span></a>    
                        <a href="/noticia/{{$postCat4->slug}}">
                        <div class="card-image" style="width:100%; height:250px; background-size: cover;  background-image:url('{{$postCat4->file}}');">
                            </div>
                        {{-- <img src="{{$postCat4->file}}" class="img-fluid" alt="">   --}}
                        </a> 
                        <br> 
                        <br>
                        <span class="categoryArticle">{{$postCat4->name}}</span> 
                        <br>
                        @foreach ($postCat4->tags as $tag)
                    <a href="{{route('tag', $tag->slug)}}"> {{$tag->name}}</a>
                    @endforeach
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-12 category">
                        <hr>
                        <a href="categoria/{{$postCat5->category->slug}}"><span class="categoryTitle">{{$postCat5->category->name}}</span></a>   
                        <a href="/noticia/{{$postCat5->slug}}">
                            <div class="card-image" style="width:100%; height:250px; background-size: cover;  background-image:url('{{$postCat5->file}}');">
                            </div>
                        {{-- <img src="{{$postCat5->file}}" class="img-fluid " alt="">    --}}
                        </a>
                        <br> 
                        <br> 
                        <span class="categoryArticle">{{$postCat5->name}}</span> 
                        <br>
                        @foreach ($postCat5->tags as $tag)
                        <a href="{{route('tag', $tag->slug)}}"> {{$tag->name}}</a>
                        @endforeach
                    </div>
                </div>
            </div>
              
            <div class="col-md-6 separador">
                <div class="othernews ">
                          
                    @foreach ($postOthers as $post)
                    <hr>
                    <div class="row">
                            <div class="col-md-4 imgOtherNew">
                                <div class="card-image" style="width:100%; height:80px; background-size: cover;  background-image:url('{{$post->file}}');">
                                </div>
                                {{-- <img src="{{$post->file}}" class=" img-fluid" alt=""> --}}
                            </div>
                            <div class="col-md-8 align-middle">
                                <span class="othernewtitle">
                                    <a href="{{route('post', $post->slug)}}">{{$post->name}}</a>
                                </span><br>
                                <span class="timeAgo text-muted">{{$post->created_at->diffforhumans()}}</span><br>
                            </div>
                    </div>
                    @endforeach   
                                        
             </div>
            </div>
        </div> 

    </div>

    <div class="col-md-3 aside separador">
        <div class="col-md-12 ">
            <div class="row ">
                <span class="categoryTitle">Opinión</span>
            <hr>
            </div>

        </div>

        @foreach ($postOpinion as $post)   
        <div class="row ">
            <div class="col-md-4" style="margin-right: -20px;">
                <div class="card-image" style="width:100%; height:70px; background-size: cover;  background-image:url('{{$post->file}}');">
                </div>
                {{-- <img src="assets/opinion/leonelcloseup.jpg" class="img-fluid" alt=""> --}}
            </div>

            <div class="col-md-8">
                <span class="tituloOpinion">
                    <a href="{{route('post', $post->slug)}}">{{$post->name}}</a><br>
                </span>
               <b class="antetitulo">{{$post->excerpt}}</b> 
            </div>
        </div> <br>
        @endforeach
           

        
        <hr>


        <div class="row">  
            
            <div class="col-md-12">  
                <span class="categoryTitle">
                    Sondeos 
                 </span> <br>
            <b>¿Se pondria usted la vacuna contra el corona virus?</b>   <br>
            <b>Si</b> <div class="progress">
                <div class="progress-bar" role="progressbar" style="width: 75%;" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100">75%</div>
              </div>

             <b>No</b>  <div class="progress">
                <div class="progress-bar bg-danger" role="progressbar" style="width: 25%;" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100">25%</div>
              </div>
            </div>
            
        </div>
        <br>
        <hr>
        <div class="row">
            
            <div class="col-md-12">
                <span class="categoryTitle">Moneda</span><br>
                <div class="fuel">
                        <p class="underline"><b>Dolar Venta:</b> {{$dollarV->price}}</p>
                        <p class="underline"><b>Dolar Compra:</b> {{$dollarC->price}}</p>
                        <p class="underline"><b>Euro Venta:</b> {{$euroV->price}}</p>
                        <p class="underline"><b>Euro Compra:</b> {{$euroC->price}}</p>
                </div>
            
            </div>
        </div>
        <hr>
        <div class="row ">
           
            <div class="col-md-12">
                <span class="categoryTitle">Combustible</span>
                <br>   

                <div class="row fuel">
                    <div class="col-md-6 align-middle "><b class="">Gasolina Premiun:</b> </div>
                    <div class="col-md-4"> <span class="">RD${{$gp->price}}</span> </div>
                    <div class="col-md-2 d-none d-md-block"><img src="assets/fuel/{{$gp->estatus}}.jpg" class=" img-fluid" alt=""></div>
                </div>
                <hr class="hrFuel">
                <div class="row fuel">
                    <div class="col-md-6"><b class="">Gasolina Regular:</b> </div>
                    <div class="col-md-4"><span class="">RD${{$gr->price}}</span></div>
                    <div class="col-md-2 d-none d-md-block"><img src="assets/fuel/{{$gr->estatus}}.jpg" class=" img-fluid" alt=""></div>
                </div>
                <hr class="hrFuel">
                <div class="row fuel">
                    <div class="col-md-6"><b class="">Diesel Premiun:</b> </div>
                    <div class="col-md-4"><span class="">RD${{$dp->price}}</span></div>
                    <div class="col-md-2 d-none d-md-block"><img src="assets/fuel/{{$dp->estatus}}.jpg" class="  img-fluid" alt=""></div>
                </div>
                <hr class="hrFuel">
                <div class="row fuel">  
                    <div class="col-md-6"><b class="">Diesel Regular:</b> </div>
                    <div class="col-md-4"><span class="">RD${{$dr->price}}</span></div>
                    <div class="col-md-2 d-none d-md-block"><img src="assets/fuel/{{$dr->estatus}}.jpg" class="  img-fluid" alt=""></div>
                </div>
                    <hr class="hrFuel">
                <div class="row fuel">
                    <div class="col-md-6"><b class="">Gas Propano:</b> </div>
                    <div class="col-md-4"><span class="">RD${{$gasp->price}}</span></div>
                    <div class="col-md-2 d-none d-md-block"><img src="assets/fuel/{{$gasp->estatus}}.jpg" class=" img-fluid" alt=""></div>
                </div>
                    <hr class="hrFuel">
                <div class="row fuel">
                    <div class="col-md-6"><b class="">Gas Natural:</b> </div>
                    <div class="col-md-4"><span class="">RD${{$gasp->price}}</span></div>
                   
                    <div class="col-md-2 d-none d-md-block"><img src="assets/fuel/{{$gasp->estatus}}.jpg" class=" img-fluid" alt=""></div>
                </div>
                <hr class="hrFuel">
                
            </div>
        </div>
            <hr>
        <div class="row">
           
                <div class="col-md-12">
                    
                <span class="categoryTitle">
                    Humor
                    </span> <br>
                    <div class="card-image" style="width:100%; height:270px; background-size: cover;  background-image:url('{{$fun->file}}');">
                    </div>
                    {{-- <img src="assets/humor/humor1.jpg" class="img-fluid" alt=""> --}}
            </div>
        </div>
    </div>

        

   
</div>

</div>
<br>

        



@endsection