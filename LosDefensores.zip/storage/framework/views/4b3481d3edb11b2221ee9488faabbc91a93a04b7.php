<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-9">
        <center>
            <h1 class="post-title"><?php echo e($post->name); ?></h1>
            <img src="<?php echo e($post->file); ?>" class="img-fluid" alt="">  
            <p class="text-muted small"><?php echo e($post->foot); ?></p>
        </center>
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
            <li class="breadcrumb-item active" aria-current="page">
                <b>Categoria: </b> 
                <a href="<?php echo e(route('category', $post->category->slug)); ?> ">&nbsp;<?php echo e($post->category->name); ?></a>
            </li>
            <li class="breadcrumb-item active" aria-current="page">
                <b>Etiquetas: </b> 
                <?php $__currentLoopData = $post->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="<?php echo e(route('tag', $tag->slug)); ?> ">&nbsp;<?php echo e($tag->name); ?></a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </li>
            <li class="breadcrumb-item active" aria-current="page">
                <b>Por: </b> 
                <?php echo e($post->user->name); ?>

            </li>
            </ol>
        </nav>
        <br> 
        <p class="text-justify border" style="padding: 10px;"> <?php echo nl2br(e($post->body)); ?></p>
            
    </div>
    <div class="col-md-3">
        <center>
            <h5>Te podria interesar</h5>
        </center>
        <hr>
        <div class="card" style="width: 18rem;">
            <ul class="list-group list-group-flush">
                <?php $__currentLoopData = $postsByCat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <li class="list-group-item"><a href="/noticia/<?php echo e($post->slug); ?>">
                <?php echo e($post->name); ?>

        </a></li>
              
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
          </div>
      
        
    </div>
    
</div>
        
<?php $__env->stopSection(); ?>
<div class="share-btn-container">
    <a href="#" target="_blank" class="facebook-btn">
      <i class="fab fa-facebook"></i>
    </a>

    <a href="#" target="_blank" class="twitter-btn">
      <i class="fab fa-twitter"></i>
    </a>
    
    <a href="#" target="_blank" class="linkedin-btn">
      <i class="fab fa-linkedin"></i>
    </a>

    <a href="#" target="_blank" class="whatsapp-btn">
      <i class="fab fa-whatsapp"></i>
    </a>
  </div>
<?php echo $__env->make('layouts.desing', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\LosDefensores\resources\views/web/post.blade.php ENDPATH**/ ?>