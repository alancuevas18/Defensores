
<div class="form-group">
    <?php echo e(Form::label('name', 'Nombre del anuncio')); ?>

    <?php echo e(Form::text('name', null, ['class' => 'form-control'])); ?>

</div>
<div class="form-group">
    <?php echo e(Form::label('url', 'Enlace')); ?>

    <?php echo e(Form::text('url', null, ['class' => 'form-control'])); ?>

</div>
<div class="form-group">
    <?php echo e(Form::label('file', 'Imagen')); ?>

    <?php echo e(Form::file('file', ['class' => 'form-control'])); ?>

</div>
<div class="form-group">
    <?php echo e(Form::submit('Guardar', ['class' => 'btn btn-sm btn-primary'])); ?>

</div>
<?php /**PATH C:\xampp\htdocs\LosDefensores\resources\views/admin/advert/partials/form.blade.php ENDPATH**/ ?>