<?php $__env->startSection('content'); ?>
    <h1>lista de Post</h1>

    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php echo e($post->name); ?>

        <br>
        <a href="<?php echo e(route('post', $post->slug)); ?>"><?php echo e($post->slug); ?></a>
        <br>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <?php echo e($posts->render()); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.desing', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\LosDefensores\resources\views/web/posts.blade.php ENDPATH**/ ?>