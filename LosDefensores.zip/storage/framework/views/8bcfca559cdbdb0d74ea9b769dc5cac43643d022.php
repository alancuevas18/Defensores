<?php echo e(Form::hidden('user_id', auth()->user()->id)); ?>


<div class="form-group">
    <?php echo e(Form::label('category_id', 'Categorias')); ?>

    <?php echo e(Form::select('category_id', $categories, null, ['class' => 'form-control'])); ?>

</div>

<div class="form-group">
    <?php echo e(Form::label('name', 'Titulo')); ?>

    <?php echo e(Form::text('name', null, ['class' => 'form-control', 'id' => 'name'])); ?>

</div>

<div class="form-group">
    <?php echo e(Form::label('slug', 'URL amigable')); ?>

    <?php echo e(Form::text('slug', null, ['class' => 'form-control', 'id' => 'permalink'])); ?>

</div>

<div class="form-group">
    <?php echo e(Form::label('file', 'Imagen')); ?>

    <?php echo e(Form::file('file', ['class' => 'form-control'])); ?>

</div>

<div class="form-group">
    <?php echo e(Form::label('foot', 'Pie de foto')); ?>

    <?php echo e(Form::text('foot', null, ['class' => 'form-control'])); ?>

</div>

<div class="form-group">
    <?php echo e(Form::label('status', 'Estado')); ?> <br>
    <label>
        <?php echo e(Form::radio('status','PUBLISHED',['class' => 'form-control'])); ?> Publicado
    </label>
    <label>
        <?php echo e(Form::radio('status','DRAFT',['class' => 'form-control'])); ?> Borrador
    </label>
</div>

<div class="form-group">
    <?php echo e(Form::label('tags', 'Etiquetas')); ?> <br>
    <div>
        <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <label>
                <?php echo e(Form::checkbox('tags[]', $tag->id)); ?> <?php echo e($tag->name); ?>

            </label>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>

<div class="form-group">
    <?php echo e(Form::label('excerpt', 'Extracto')); ?>

    <?php echo e(Form::textarea('excerpt', null, ['class' => 'form-control', 'rows' => '2'])); ?>

</div>

<div class="form-group">
    <?php echo e(Form::label('body', 'Descripcion')); ?>

    <?php echo e(Form::textarea('body', null, ['class' => 'form-control'])); ?>

</div>

<div class="form-group">
    <?php echo e(Form::submit('Guardar', ['class' => 'btn btn-sm btn-primary'])); ?>

</div>

<?php $__env->startSection('scripts'); ?>
<script src="http://code.jquery.com/jquery-1.12.3.min.js"></script>
<script src="<?php echo e(asset('vendor/stringToSlug/slugger.js')); ?>"></script>
<script>
$('#permalink').slugger({
    source: '#name',
	readonly: true
});
</script>
<?php $__env->stopSection(); ?><?php /**PATH C:\xampp\htdocs\LosDefensores\resources\views/admin/posts/partials/form.blade.php ENDPATH**/ ?>