<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-10 offset-md-1">
                
                <div class="card">
                    <div class="card-header">
                      Editar Entrada
                    </div>
                    
                    <div class="card-body">
                        <?php echo Form::model($category, ['route' => ['categories.update', $category->id], 'method' => 'PUT']); ?>

                            <?php echo $__env->make('admin.categories.partials.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
                        <?php echo Form::close(); ?>

                    </div>
                  </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\LosDefensores\resources\views/admin/categories/edit.blade.php ENDPATH**/ ?>