<div class="form-group">
    <?php echo e(Form::label('name', 'Nombre de la etiqueta')); ?>

    <?php echo e(Form::text('name', null, ['class' => 'form-control', 'id' => 'name'])); ?>

</div>
<div class="form-group">
    <?php echo e(Form::label('slug', 'URL amigable')); ?>

    <?php echo e(Form::text('slug', null, ['class' => 'form-control', 'id' => 'permalink'])); ?>

</div>
<div class="form-group">
    <?php echo e(Form::label('body', 'Descripcion')); ?>

    <?php echo e(Form::textarea('body', null, ['class' => 'form-control'])); ?>

</div>
<div class="form-group">
    <?php echo e(Form::submit('Guardar', ['class' => 'btn btn-sm btn-primary'])); ?>

</div>

<?php $__env->startSection('scripts'); ?>
<script src="http://code.jquery.com/jquery-1.12.3.min.js"></script>
<script src="<?php echo e(asset('vendor/stringToSlug/slugger.js')); ?>"></script>
<script>
$('#permalink').slugger({
    source: '#name',
	readonly: true
});
</script>
<?php $__env->stopSection(); ?><?php /**PATH C:\xampp\htdocs\LosDefensores\resources\views/admin/categories/partials/form.blade.php ENDPATH**/ ?>