<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-10 offset-md-1">
                <center>
                    <h1>Detalles</h1>
                </center>
                
                <div class="card">
                   <p><strong>Nombre: </strong><?php echo e($economy->name); ?></p>
                   <p><strong>Precio: </strong><?php echo e($economy->price); ?></p>
                   <p><strong>Estado: </strong><?php echo e($economy->estatus); ?></p>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\LosDefensores\resources\views/admin/economies/show.blade.php ENDPATH**/ ?>