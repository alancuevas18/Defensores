<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-10 offset-md-1">
                <center>
                    <h1>Detalles de la categoria</h1>
                </center>
                
                <div class="card">
                   <p><strong>Nombre: </strong><?php echo e($category->name); ?></p>
                   <p><strong>Descripcion: </strong><?php echo e($category->body); ?></p>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\LosDefensores\resources\views/admin/categories/show.blade.php ENDPATH**/ ?>