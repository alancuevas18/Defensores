<?php $__env->startSection('advert'); ?>
<center>
    <a href=" <?php echo e($advert->url); ?> " target="_blank">
        <img src=" <?php echo e($advert->file); ?> " alt="alternative text" title="<?php echo e($advert->name); ?>" class="img-fluid" alt="">
    </a>
</center>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>

<div class="row main-new">
    <div class="col-md-6 descripcion">
       <a href="categoria/<?php echo e($postCat1->category->slug); ?>"><span class="lastMin"><?php echo e($postCat1->category->name); ?></span></a> 
            <br>
            <br>
       <span class="MainNewTitle"><?php echo e($postCat1->name); ?></span>
            <br>
            <br>

       <span class="MainExtract" >
           <p>
            <?php echo e($postCat1->excerpt); ?> </p>
            <b>Etiquetas:</b>
            <?php $__currentLoopData = $postCat1->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    
            <a href="<?php echo e(route('tag', $tag->slug)); ?>"> <?php echo e($tag->name); ?></a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
       </span>
       
       <p class="text-right"><a href="noticia/<?php echo e($postCat1->slug); ?>">Continuar Leyendo</a></p>
    </div>
    <div class="col-md-6 imagen">
        <a href="/noticia/<?php echo e($postCat1->slug); ?>">
        <img src="<?php echo e($postCat1->file); ?>" class="img-fluid" alt="">
        </a>
        <p class="text-muted small"><?php echo e($postCat1->foot); ?></p>
    </div>
</div>

    <hr>
<div class="row news">
    <div class="col-md-9 news">
        <div class="row">
            <div class="col-md-6 category">
                <a href="categoria/<?php echo e($postCat2->category->slug); ?>"><span class="categoryTitle"><?php echo e($postCat2->category->name); ?></span></a>
                <a href="/noticia/<?php echo e($postCat2->slug); ?>">
                    <div class="card-image" style="width:100%; height:250px; background-size: cover;  background-image:url('<?php echo e($postCat2->file); ?>');">
                    </div>
                
                </a>  
                <br> 
                <br> 
                <span class="categoryArticle"><?php echo e($postCat2->name); ?></span> 
                <br>
                <?php $__currentLoopData = $postCat2->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e(route('tag', $tag->slug)); ?>"> <?php echo e($tag->name); ?></a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <div class="col-md-6 category separador">
                <a href="categoria/<?php echo e($postCat3->category->slug); ?>"><span class="categoryTitle"><?php echo e($postCat3->category->name); ?></span></a>    
                <a href="/noticia/<?php echo e($postCat3->slug); ?>">
                    <div class="card-image" style="width:100%; height:250px; background-size: cover;  background-image:url('<?php echo e($postCat3->file); ?>');">
                    </div>
                
                </a>
                <br> 
                <br> 
                <span class="categoryArticle"><?php echo e($postCat3->name); ?></span> 
                <br>
                    <?php $__currentLoopData = $postCat3->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e(route('tag', $tag->slug)); ?>"> <?php echo e($tag->name); ?></a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
        <br>
        <div class="row">

            <div class="col-md-6">       
                <div class="row">
                    <div class="col-md-12 category ">
                        <hr>
                        <a href="categoria/<?php echo e($postCat4->category->slug); ?>"><span class="categoryTitle"><?php echo e($postCat4->category->name); ?></span></a>    
                        <a href="/noticia/<?php echo e($postCat4->slug); ?>">
                        <div class="card-image" style="width:100%; height:250px; background-size: cover;  background-image:url('<?php echo e($postCat4->file); ?>');">
                            </div>
                        
                        </a> 
                        <br> 
                        <br>
                        <span class="categoryArticle"><?php echo e($postCat4->name); ?></span> 
                        <br>
                        <?php $__currentLoopData = $postCat4->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e(route('tag', $tag->slug)); ?>"> <?php echo e($tag->name); ?></a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-12 category">
                        <hr>
                        <a href="categoria/<?php echo e($postCat5->category->slug); ?>"><span class="categoryTitle"><?php echo e($postCat5->category->name); ?></span></a>   
                        <a href="/noticia/<?php echo e($postCat5->slug); ?>">
                            <div class="card-image" style="width:100%; height:250px; background-size: cover;  background-image:url('<?php echo e($postCat5->file); ?>');">
                            </div>
                        
                        </a>
                        <br> 
                        <br> 
                        <span class="categoryArticle"><?php echo e($postCat5->name); ?></span> 
                        <br>
                        <?php $__currentLoopData = $postCat5->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e(route('tag', $tag->slug)); ?>"> <?php echo e($tag->name); ?></a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
              
            <div class="col-md-6 separador">
                <div class="othernews ">
                          
                    <?php $__currentLoopData = $postOthers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <hr>
                    <div class="row">
                            <div class="col-md-4 imgOtherNew">
                                <div class="card-image" style="width:100%; height:80px; background-size: cover;  background-image:url('<?php echo e($post->file); ?>');">
                                </div>
                                
                            </div>
                            <div class="col-md-8 align-middle">
                                <span class="othernewtitle">
                                    <a href="<?php echo e(route('post', $post->slug)); ?>"><?php echo e($post->name); ?></a>
                                </span><br>
                                <span class="timeAgo text-muted"><?php echo e($post->created_at->diffforhumans()); ?></span><br>
                            </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>   
                                        
             </div>
            </div>
        </div> 

    </div>

    <div class="col-md-3 aside separador">
        <div class="col-md-12 ">
            <div class="row ">
                <span class="categoryTitle">Opinión</span>
            <hr>
            </div>

        </div>

        <?php $__currentLoopData = $postOpinion; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>   
        <div class="row ">
            <div class="col-md-4" style="margin-right: -20px;">
                <div class="card-image" style="width:100%; height:70px; background-size: cover;  background-image:url('<?php echo e($post->file); ?>');">
                </div>
                
            </div>

            <div class="col-md-8">
                <span class="tituloOpinion">
                    <a href="<?php echo e(route('post', $post->slug)); ?>"><?php echo e($post->name); ?></a><br>
                </span>
               <b class="antetitulo"><?php echo e($post->excerpt); ?></b> 
            </div>
        </div> <br>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           

        
        <hr>


        <div class="row">  
            
            <div class="col-md-12">  
                <span class="categoryTitle">
                    Sondeos 
                 </span> <br>
            <b>¿Se pondria usted la vacuna contra el corona virus?</b>   <br>
            <b>Si</b> <div class="progress">
                <div class="progress-bar" role="progressbar" style="width: 75%;" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100">75%</div>
              </div>

             <b>No</b>  <div class="progress">
                <div class="progress-bar bg-danger" role="progressbar" style="width: 25%;" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100">25%</div>
              </div>
            </div>
            
        </div>
        <br>
        <hr>
        <div class="row">
            
            <div class="col-md-12">
                <span class="categoryTitle">Moneda</span><br>
                <div class="fuel">
                        <p class="underline"><b>Dolar Venta:</b> <?php echo e($dollarV->price); ?></p>
                        <p class="underline"><b>Dolar Compra:</b> <?php echo e($dollarC->price); ?></p>
                        <p class="underline"><b>Euro Venta:</b> <?php echo e($euroV->price); ?></p>
                        <p class="underline"><b>Euro Compra:</b> <?php echo e($euroC->price); ?></p>
                </div>
            
            </div>
        </div>
        <hr>
        <div class="row ">
           
            <div class="col-md-12">
                <span class="categoryTitle">Combustible</span>
                <br>   

                <div class="row fuel">
                    <div class="col-md-6 align-middle "><b class="">Gasolina Premiun:</b> </div>
                    <div class="col-md-4"> <span class="">RD$<?php echo e($gp->price); ?></span> </div>
                    <div class="col-md-2 d-none d-md-block"><img src="assets/fuel/<?php echo e($gp->estatus); ?>.jpg" class=" img-fluid" alt=""></div>
                </div>
                <hr class="hrFuel">
                <div class="row fuel">
                    <div class="col-md-6"><b class="">Gasolina Regular:</b> </div>
                    <div class="col-md-4"><span class="">RD$<?php echo e($gr->price); ?></span></div>
                    <div class="col-md-2 d-none d-md-block"><img src="assets/fuel/<?php echo e($gr->estatus); ?>.jpg" class=" img-fluid" alt=""></div>
                </div>
                <hr class="hrFuel">
                <div class="row fuel">
                    <div class="col-md-6"><b class="">Diesel Premiun:</b> </div>
                    <div class="col-md-4"><span class="">RD$<?php echo e($dp->price); ?></span></div>
                    <div class="col-md-2 d-none d-md-block"><img src="assets/fuel/<?php echo e($dp->estatus); ?>.jpg" class="  img-fluid" alt=""></div>
                </div>
                <hr class="hrFuel">
                <div class="row fuel">  
                    <div class="col-md-6"><b class="">Diesel Regular:</b> </div>
                    <div class="col-md-4"><span class="">RD$<?php echo e($dr->price); ?></span></div>
                    <div class="col-md-2 d-none d-md-block"><img src="assets/fuel/<?php echo e($dr->estatus); ?>.jpg" class="  img-fluid" alt=""></div>
                </div>
                    <hr class="hrFuel">
                <div class="row fuel">
                    <div class="col-md-6"><b class="">Gas Propano:</b> </div>
                    <div class="col-md-4"><span class="">RD$<?php echo e($gasp->price); ?></span></div>
                    <div class="col-md-2 d-none d-md-block"><img src="assets/fuel/<?php echo e($gasp->estatus); ?>.jpg" class=" img-fluid" alt=""></div>
                </div>
                    <hr class="hrFuel">
                <div class="row fuel">
                    <div class="col-md-6"><b class="">Gas Natural:</b> </div>
                    <div class="col-md-4"><span class="">RD$<?php echo e($gasp->price); ?></span></div>
                   
                    <div class="col-md-2 d-none d-md-block"><img src="assets/fuel/<?php echo e($gasp->estatus); ?>.jpg" class=" img-fluid" alt=""></div>
                </div>
                <hr class="hrFuel">
                
            </div>
        </div>
            <hr>
        <div class="row">
           
                <div class="col-md-12">
                    
                <span class="categoryTitle">
                    Humor
                    </span> <br>
                    <div class="card-image" style="width:100%; height:270px; background-size: cover;  background-image:url('<?php echo e($fun->file); ?>');">
                    </div>
                    
            </div>
        </div>
    </div>

        

   
</div>

</div>
<br>

        



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.desing', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\LosDefensores\resources\views/web/home.blade.php ENDPATH**/ ?>