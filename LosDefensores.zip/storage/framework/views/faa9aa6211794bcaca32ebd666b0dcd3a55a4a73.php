<?php $__env->startSection('content'); ?>
<center>
    <h1><?php echo e($tagName); ?></h1>
</center>

<div class="col-md-12 news">
    <div class="row">
    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-6 category">
            <hr>
            <span class="categoryTitle"><a href="/categoria/<?php echo e($post->category->slug); ?>"><?php echo e($post->category->name); ?></a></span>    
            <a href="/noticia/<?php echo e($post->slug); ?>">
                <img src="/assets/news/casos.jpg" class="img-fluid" alt="">
            </a>
            <br> 
            <br> 
            <span class="categoryArticle"><?php echo e($post->name); ?></span> 
            <br>
            <?php $__currentLoopData = $post->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="<?php echo e(route('tag', $tag->slug)); ?>"> <?php echo e($tag->name); ?></a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <br>
        </div>
       
    
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   
</div>
<hr>
<center>
    <?php echo e($posts->render()); ?>

</center>
    
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.desing', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\LosDefensores\resources\views/web/tags.blade.php ENDPATH**/ ?>