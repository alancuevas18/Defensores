<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-10 offset-md-1">
                <center>
                    <h1>Detalles de la entrada</h1>
                </center>
                
                <div class="card">
                   <p><strong>Nombre: </strong><?php echo e($post->name); ?></p>
                   <p><strong>Descripcion: </strong><?php echo e($post->body); ?></p>
                   <p><strong>Pie de foto: </strong><?php echo e($post->foot); ?></p>
                   <p><strong>Status: </strong><?php echo e($post->status); ?></p>
                   <img src="<?php echo e($post->file); ?>" alt="">

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\LosDefensores\resources\views/admin/posts/show.blade.php ENDPATH**/ ?>